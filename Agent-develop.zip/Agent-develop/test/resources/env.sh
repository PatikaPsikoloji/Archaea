export USAGE="5"
export AGENT_IMAGE="gcr.io/focal-freedom-236620/agent:latest"
export CONTROLLER_IMAGE="iofog/controller:latest"
export NAMESPACE="int-test"