#!/bin/bash

echo "Upgrading ioFog-Agent package ..."
