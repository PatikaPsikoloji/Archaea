package org.eclipse.iofog.local_api;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LocalApiServerHandlerTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void channelRead0() {
    }

    @Test
    public void channelReadComplete() {
    }

    @Test
    public void exceptionCaught() {
    }
}