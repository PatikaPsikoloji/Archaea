package org.eclipse.iofog.field_agent.enums;

public enum RequestType {
    GET,
    POST,
    PATCH,
    PUT,
    DELETE
}
