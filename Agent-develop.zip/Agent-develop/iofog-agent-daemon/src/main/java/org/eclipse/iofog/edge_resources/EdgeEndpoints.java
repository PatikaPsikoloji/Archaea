/*
 * *******************************************************************************
 *  * Copyright (c) 2018-2022 Edgeworx, Inc.
 *  *
 *  * This program and the accompanying materials are made available under the
 *  * terms of the Eclipse Public License v. 2.0 which is available at
 *  * http://www.eclipse.org/legal/epl-2.0
 *  *
 *  * SPDX-License-Identifier: EPL-2.0
 *  *******************************************************************************
 *
 */
package org.eclipse.iofog.edge_resources;

public class EdgeEndpoints {

    private int id;
    private String name;
    private String description;
    private String method;
    private String url;
    private String requestType;
    private String responseType;
    private String requestPayloadExample;
    private String responsePayloadExample;
    private int interfaceId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getResponseType() {
        return responseType;
    }

    public void setResponseType(String responseType) {
        this.responseType = responseType;
    }

    public String getRequestPayloadExample() {
        return requestPayloadExample;
    }

    public void setRequestPayloadExample(String requestPayloadExample) {
        this.requestPayloadExample = requestPayloadExample;
    }

    public String getResponsePayloadExample() {
        return responsePayloadExample;
    }

    public void setResponsePayloadExample(String responsePayloadExample) {
        this.responsePayloadExample = responsePayloadExample;
    }

    public int getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(int interfaceId) {
        this.interfaceId = interfaceId;
    }

}