package org.eclipse.iofog.microservice;

public enum VolumeMappingType {
    VOLUME,
    BIND
}
